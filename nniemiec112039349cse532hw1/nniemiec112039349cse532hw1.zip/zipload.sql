load from "zip_code_database.csv" of del method P(1, 7, 8, 15) replace into CSE532.ZIPPOP (ZIP, STATE, COUNTY, POP);
